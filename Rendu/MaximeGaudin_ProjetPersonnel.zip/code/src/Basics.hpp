#include <Ray.hpp>
#include <HitRecord.hpp>
#include <Material.hpp>
#include <DefaultSampler.hpp>
#include <Scene.hpp>
