#ifndef COMMON_H_
#define COMMON_H_
#include <config.hpp>

#ifndef feach
  #define feach BOOST_FOREACH
#endif

#endif
